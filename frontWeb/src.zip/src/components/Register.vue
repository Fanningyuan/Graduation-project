<template>
    <div style="margin-top:60px">
        <img style="width:250px" src=".././assets/0.jpg"><br/>
        <input type="text" placeholder="请输入用户名"/><br>
        <input type="password" placeholder="请输入密码"/><br>
        <input type="password" placeholder="请再输入一次密码"/><br>
        <button>注册</button>
    </div>
</template>

<style>
    input {
        width: 340px;
        padding: 0 25px;
        height: 44px;
        border: 1px solid #f2f2f2;
        background: #f6f6f6;
        color: #202124;
        font-size: 14px;
        line-height: 48px;
        border-radius: 15px;
        margin-top:18px;
        margin-left:540px;
    }
    img{
        width:250px;
        height:250px;
        border-radius: 60px;
        overflow:hidden;
        margin-left:600px;
    }
    button{
        width:75px;
        height:40px;
        border-radius: 5px;
        margin-top:30px;
        margin-left:680px;
    }
</style>